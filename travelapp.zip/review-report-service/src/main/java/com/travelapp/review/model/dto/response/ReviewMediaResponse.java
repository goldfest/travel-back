package com.travelapp.review.model.dto.response;

import com.travelapp.review.model.entity.ReviewMedia;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReviewMediaResponse {

    private Long id;
    private String imageUrl;
    private String thumbnailUrl;
    private ReviewMedia.SourceType sourceType;
    private ReviewMedia.ModerationStatus moderationStatus;
    private String originalFilename;
    private String contentType;
    private Long fileSize;
    private Long userId;
    private LocalDateTime createdAt;
}