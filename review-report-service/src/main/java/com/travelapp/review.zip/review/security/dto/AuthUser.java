package com.travelapp.review.security.dto;

import lombok.Data;

@Data
public class AuthUser {
    private Long id;

    /**
     * Например: USER / ADMIN / MODERATOR
     */
    private String role;

    /**
     * Например: ACTIVE / BLOCKED (если у вас так)
     */
    private String status;

    /**
     * Если auth-service отдает флаг блокировки
     */
    private Boolean isBlocked;

    /**
     * Доп. поля (полезны для отображения отзывов)
     */
    private String username;
    private String avatarUrl;

    /**
     * Если у вас есть такое поле в профиле
     */
    private Long homeCityId;
}