package com.travelapp.review.service;

import com.travelapp.review.client.AuthClient;
import com.travelapp.review.security.dto.AuthUser;
import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthUserResolverService {

    private final AuthClient authClient;

    @Cacheable(value = "authUsers", key = "#userId", unless = "#result == null")
    public AuthUser getUserInfoSafe(Long userId) {
        if (userId == null) {
            return null;
        }

        try {
            return authClient.getUserInfo(userId);
        } catch (FeignException.NotFound e) {
            log.warn("User not found in auth-service: {}", userId);
            return null;
        } catch (FeignException e) {
            log.warn("Auth-service error while fetching user info {}: {}", userId, e.getMessage());
            return null;
        } catch (Exception e) {
            log.warn("Unexpected error while fetching user info {}: {}", userId, e.toString());
            return null;
        }
    }
}